
public class ExpressoesAtribuicoes {
	
	private static int a;
	private static int b;
	
	private static void startAvaliaOperandos() {
		a = 10; b = 0;
		b = a + mudaA();
		System.out.println("A = " + a + ", B = " + b);
		
		a = 10; b = 0;
		b = mudaA() + a;
		System.out.println("A = " + a + ", B = " + b);
		
	}
	
	private static int mudaA() {
		a = 100;
		return 1000;
	}
	
	private static void start() {
		byte a, b;
		a = 10;
		b = 100;
		
		int c = (a * b);
		
		System.out.println("C � : " + c);
		
	}

	public static void main(String[] args) {
		start();
		startAvaliaOperandos();
	}

}
